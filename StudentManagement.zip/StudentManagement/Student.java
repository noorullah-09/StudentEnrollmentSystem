package StudentManagement;

import java.util.ArrayList;
import java.util.List;

class Student {
    private String name;
    private int rollNumber;
    private List<Course> listOfEnrolledCourses;

    public Student(String name, int rollNumber) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.listOfEnrolledCourses = new ArrayList<>(); // Initialize the list here
    }

    public Student(int studentId, String name2, String rollNumber2) {
		// TODO Auto-generated constructor stub
	}

	public void enrollInCourse(Course course) {
        listOfEnrolledCourses.add(course);
    }

    public void displayInfo() {
    	System.out.println("-----------------------------");
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Enrolled Courses: " + enrolledCoursesToString());
        System.out.println("------------------------------");
    }

    private String enrolledCoursesToString() {
        StringBuilder coursesString = new StringBuilder();
        for (Course course : listOfEnrolledCourses) {
            coursesString.append(course.getName()).append(", ");
        }
        if (coursesString.length() > 2) {
            coursesString.setLength(coursesString.length() - 2); // Remove the trailing comma and space
        }
        return coursesString.toString();
    }

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	public int getRollNumber() {
		// TODO Auto-generated method stub
		return rollNumber;
	}

	public List<Course> getListOfEnrolledCourses() {
		// TODO Auto-generated method stub
		return listOfEnrolledCourses;
	}
}

// Rest of the code remains unchanged
