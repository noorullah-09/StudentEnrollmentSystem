package StudentManagement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainStudentManagement {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Database connection
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/day4", // JDBC URL
                    "root", // Database username
                    "Noorullah@09"  // Database password
            );

            List<Student> students = new ArrayList<>();
            List<Course> courses = new ArrayList<>();

            // Input for Students
            System.out.println("Enter the number of students: ");
            int numberOfStudents = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            for (int i = 1; i <= numberOfStudents; i++) {
                System.out.println("Enter details for Student " + i + ":");
                Student student = getStudentDetails(scanner);
                students.add(student);

                // Input for Courses for each student
                System.out.println("Enter the number of courses for Student " + i + ":");
                int numberOfCourses = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                for (int j = 1; j <= numberOfCourses; j++) {
                    System.out.println("Enter details for Course " + j + ":");
                    Course course = getCourseDetails(scanner);
                    courses.add(course);

                    // Enroll the student in the course
                    student.enrollInCourse(course);
                }
            }

            // Display Student Information
            System.out.println("Student Information:");
            for (Student student : students) {
                student.displayInfo();
            }

            // Display Course Information
            System.out.println("Course Information:");
            for (Course course : courses) {
                course.displayInfo();
            }

            // Insert data into the database
            insertDataIntoDatabase(connection, students, courses);

            // Close the connection when done
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        scanner.close();
    }

    private static Student getStudentDetails(Scanner scanner) {
        System.out.println("Name: ");
        String name = scanner.nextLine(); // Use nextLine to capture full names

        System.out.println("Roll Number: ");
        int rollno;
        while (true) {
            try {
                rollno = scanner.nextInt();
                break; // Break out of the loop if the input is an integer
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid roll number:");
                scanner.nextLine(); // Consume the invalid input
            }
        }
        scanner.nextLine(); // Consume the newline character

        return new Student(name, rollno);
    }

    private static Course getCourseDetails(Scanner scanner) {
        Course course = null;
        boolean validInput = false;

        while (!validInput) {
            try {
                System.out.print("Course Code: ");
                String courseCode = scanner.next();
                System.out.print("Name: ");
                String name = scanner.next();
                System.out.print("Credits: ");
                int credits = scanner.nextInt();

                course = new Course(courseCode, name, credits);
                validInput = true;
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter valid course details.");
                scanner.nextLine(); // Consume the invalid input
            }
        }

        scanner.nextLine(); // Consume the newline character
        return course;
    }


    private static void insertDataIntoDatabase(Connection connection, List<Student> students, List<Course> courses)
            throws SQLException {
        // Insert data into student table
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO student4 (student_name, roll_number) VALUES (?, ?)")) {
            for (Student student : students) {
                statement.setString(1, student.getName());
                statement.setInt(2, student.getRollNumber());
                statement.executeUpdate();
            }
        }

        // Insert data into course table
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO course4 (course_code, course_name, course_credits) VALUES (?, ?, ?)")) {
            for (Course course : courses) {
                statement.setString(1, course.getCourseCode());
                statement.setString(2, course.getName());
                statement.setInt(3, course.getCredits());
                statement.executeUpdate();
            }
        }

        // Insert data into enrollment table
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO enrollment (student_id, course_id) VALUES (?, ?)")) {
            for (Student student : students) {
                int studentId = getStudentId(connection, student.getName());
                for (Course course : student.getListOfEnrolledCourses()) {
                    int courseId = getCourseId(connection, course.getName());
                    statement.setInt(1, studentId);
                    statement.setInt(2, courseId);
                    statement.executeUpdate();
                }
            }
        }
    }

    private static int getStudentId(Connection connection, String studentName) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT student_id FROM student4 WHERE student_name = ?")) {
            statement.setString(1, studentName);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("student_id");
                }
                return -1; // Return -1 if not found
            }
        }
    }

    private static int getCourseId(Connection connection, String courseName) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT course_id FROM course4 WHERE course_name = ?")) {
            statement.setString(1, courseName);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("course_id");
                }
                return -1; // Return -1 if not found
            }
        }
    }
}
