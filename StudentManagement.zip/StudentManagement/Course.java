package StudentManagement;

public class Course {

	private String courseCode;
	private String CourseName;
	private int credits;
	
	
	public Course(String courseCode, String CourseName, int credits) {
		
		this.courseCode = courseCode;

		this.CourseName = CourseName;
		this.credits = credits;
	}
	
	public Course(int courseId, int courseCode2, String name, int credits2) {
		// TODO Auto-generated constructor stub
	}

	public void displayInfo() {
		System.out.println("Course code : " + courseCode);
		System.out.println("Course Name : " + CourseName);
		System.out.println("Course Credits : " + credits);
		System.out.println("--------------------------------------");
	}


	public String getName() {
		// TODO Auto-generated method stub
		return CourseName;
	}

	public String getCourseCode() {
		// TODO Auto-generated method stub
		return courseCode;
	}

	public int getCredits() {
		// TODO Auto-generated method stub
		return credits;
	}
}
